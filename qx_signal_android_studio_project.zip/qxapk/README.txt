QX SIGNAL DASHBOARD - Android Studio project

This is an Android Studio project source, not a compiled APK.

BUILD:
1. Install Android Studio on a PC.
2. Open this folder in Android Studio (File > Open).
3. Wait for Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When finished, Android Studio shows a link to the APK (app/build/outputs/apk/debug/app-debug.apk).
6. Transfer APK to phone and install (allow Install unknown apps for the file manager if Android asks).

Dashboard supports Yahoo Finance chart data for symbols available on Yahoo Finance. Example symbols: EURUSD=X, GBPUSD=X, USDJPY=X, BTC-USD, GC=F. OTC markets are not supported. Telegram settings panel is placeholder only (not connected yet).
Signals are indicator-based only, not verified probabilities or financial advice.
