package com.example.qxsignal;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import java.net.*; import java.io.*;
public class MainActivity extends Activity {
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebChromeClient(new WebChromeClient()); w.addJavascriptInterface(new Bridge(),"AndroidBridge"); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
 class Bridge { @JavascriptInterface public void load(String symbol,String interval){new Thread(()->{try{String range="1d"; if(interval.equals("5m"))range="5d";else if(interval.equals("15m"))range="5d";else if(interval.equals("30m"))range="1mo";else if(interval.equals("1h"))range="1mo";else if(interval.equals("4h"))range="3mo";else if(interval.equals("1d"))range="6mo"; String url="https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(symbol,"UTF-8")+"?interval="+interval+"&range="+range; HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestProperty("User-Agent","Mozilla/5.0");c.setConnectTimeout(10000);c.setReadTimeout(10000); InputStream is=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=is.read(buf))>0)out.write(buf,0,n);String json=out.toString("UTF-8");runOnUiThread(()->w.evaluateJavascript("window.onData(\'"+JSONObjectSafe(json)+"\')",null));}catch(Exception e){runOnUiThread(()->w.evaluateJavascript("window.onError('Data unavailable: "+e.getMessage().replace("'"," ")+"')",null));}}).start(); }
 String JSONObjectSafe(String s){return s.replace("\\","\\\\").replace("'","\\'");}
 }
}
